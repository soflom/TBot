from .bot_start import dp
#from .start import dp
from .help import dp
from .hello import dp
from .menu import dp
from .buttons import dp
from .test import dp
from .inline_menu import dp
from .register import dp

from .error import dp

__all__ = ['dp']
